public class StudentInterface {
	
	String key = null;
	
	
	public void addCourse(int[] courseCode, String[] school, int[] indexNum, boolean[] vacancy)
	{
		
	}
	public void dropCourse(int[] courseCode, String[] school, int[] indexNum, boolean[] vacancy)
	{
		
	}
	public void checkVacancy()
	{
		
	}
	public void swapIndexNum()
	{
		
	}
}
