
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class LoginController {
	private String[] adminUsername;
	private String[] adminPassword;
	private String[] studentUsername;
	private String[] studentPassword;
	private boolean isAdmin;
	
	private int choice;
	
	String filename = null;
	String key = null;
	TextDatabase textDatabase = new TextDatabase();
	
	public LoginController()
	{
		//retrieve login information from txt file
	}

	
	public void validateLogin(String username, String password, int choice) // Called from LoginInterface
	{
		try {
			if(choice == 1)
			{
				filename = "StudentLogins.txt"; 
				key = TextDatabase.readStudentsLogin(filename, username, password); //push to TextDatabase
				if(key != null)
				{
					System.out.println("\nSuccessful Login\n");	
				}
		    	else
		    	{
		    		System.out.println("Incorrect Password or Username!");
		    	}
		    		
    		}
			else if(choice == 2)
			{
				filename = "AdminLogins.txt";
				 ArrayList al = TextDatabase.readAdmin(filename); //using ArrayList copy pasted from Prof
		    		for (int i = 0 ; i < al.size() ; i++) {
		    			Admin admin = (Admin)al.get(i); //called admin.java
		    			//System.out.println("Username: " + admin.getUsername() );
						//System.out.println("Password: " + admin.getPassword() );
						//System.out.println("Key: " + admin.getKey());
		    			if((username.equals(admin.getUsername())) && (password.equals(admin.getPassword())))
		    			{
		    				key = admin.getKey();
		    				System.out.println("Successful Login");
		    				break;
		    			}
		    		}
		    			//System.out.println("Incorrect username or password.");
			}
    	  		 		
    	}catch (IOException e) {
			System.out.println("IOException > " + e.getMessage());
    	}
	
    	
	}
}
