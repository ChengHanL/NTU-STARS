import java.util.Scanner;

public class LoginInterface {
	
	public LoginInterface() {}
	
	public void LoginAs() //Enter from mySTARSApp
	{
		LoginInterface loginInterface = new LoginInterface();
		int choice;
		Scanner sc = new Scanner(System.in);
		
		while(true) {
			System.out.println("Login As..... ");
			System.out.println("1 For Student \n2 For Admin ");
			System.out.printf("Enter choice: ");
			choice = sc.nextInt();
			if(choice == 1 || choice == 2)
			{
				loginInterface.AdminOrStudent(choice); //Enter AdminOrStudent
			}
		}
	}
	private void AdminOrStudent(int choice)
	{
		LoginController loginController = new LoginController(); //Enter loginController
		String username, password;
		//boolean adminValidated = false, studentValidated = false;
		
		Scanner sc = new Scanner(System.in);
		Scanner xc = new Scanner(System.in);
		System.out.println("\nLogin.....");
		System.out.printf("Please enter Username: ");
		username = sc.next();
		System.out.printf("Please Enter Password: ");
		password = xc.next();
		
		loginController.validateLogin(username, password, choice); //Enter loginController.validateLogin
	}
}
