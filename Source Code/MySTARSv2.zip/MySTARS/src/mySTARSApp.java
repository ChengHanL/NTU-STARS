import java.util.Scanner;

public class mySTARSApp {
	//Plane myPlane = new Plane();
	public static void main(String[] args) {
		LoginInterface loginInterface = new LoginInterface();	//from mySTARSApp to LoginInterface	
		loginInterface.LoginAs();
	}		
}
