
public class AdminInterface {
	private Student[] myStudent;
	
	
	public AdminInterface() {
		
	}
	public void printstudentList()
	{
		
	}
	private Student[] sortedCourseNum()
	{
		Student[] sortedbyCourseNum = myStudent.clone();
		//insertion sort
		return null;
	}
	public void editAccessPeriod()
	{
		
	}
	public void addStudent()
	{
		
	}
	public void updateAddCourse(int courseCode, String school, int indexNum, int vacancy)
	{
		
	}
	public void checkSlot(int indexNum)
	{
		
	}
}
